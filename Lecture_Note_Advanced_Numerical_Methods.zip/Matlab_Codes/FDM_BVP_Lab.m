%% Centeral Finite Difference Scheme for  the problem
%      -u''(x) +a(X)u'(x)+ b(x) u(x) = f(x) on (0,1)
%          u(0)=alpha, u(1) = beta.
% on a uniform mesh
clc
clear all;
close all
%% Problem Data
alpha = 1; beta = 3;
b = @(x)(x*0);
a=  @(x)(-1+x*0);
f = @(x)(-1+x*0);
u = @(x)(1 + x+(exp(x)-1)/(exp(1)-1));
% b = @(x)(4+x*0);
% f = @(x)(1+exp(x));

%% Data for numerical method
N = 16;

%% Set up the mesh
h = 1/N;
x = linspace(0, 1, N+1)';

%% Construct the Central Finite Difference Linear System
% 
A(1,1) = 1;
B(1) = alpha;
for i=2:N
    A(i,i-1) = 1/h^2-a(x(i))/(2*h);
    A(i,i)   = -2/h^2 + b(x(i));
    A(i,i+1) = 1/h^2+a(x(i))/(2*h);
    
    B(i) = f(x(i));
end
A(N+1,N+1)=1;  B(N+1) = beta;
A
%% Solve the linear system
U = A\B';
for i=1:N+1
    x(i)=(i-1)*h;
uexact(i)=u(x(i));
end
%% Plot the output
figure(1); plot(x, U, '-o',x,uexact,'-*'); legend( 'Centeral Diff', 'Exact Sol' ); hold on
ErrorCentral = U-uexact'
ErrormaxCentral = max(abs(U-uexact'))

% 


%% Construct the upwind Finite Difference Linear System

A(1,1) = 1;
B(1) = alpha;
for i=2:N
    A(i,i-1) = 1/h^2-a(x(i))/h;
    A(i,i)   = -2/h^2 +a(x(i))/h+ b(x(i));
    A(i,i+1) = 1/h^2;
    
    B(i) = f(x(i));
end
A(N+1,N+1)=1;
B(N+1) = beta;

%% Solve the linear system
U = A\B';
for i=1:N+1
    x(i)=(i-1)*h;
uexact(i)=u(x(i));
end


%% Plot the output
figure(2); plot(x, U, '-o r',x,uexact,'-*');legend( 'Upwind FDM', 'Exact Sol' ); hold on
ErrorUpwind = U-uexact'
Errormaxupwind = max(abs(U-uexact'))
figure(3); plot(x,ErrorCentral, 'm*', x, ErrorUpwind, '-*');legend('Error of Centeral FDM', 'Error of Upwind FDM'); hold on

